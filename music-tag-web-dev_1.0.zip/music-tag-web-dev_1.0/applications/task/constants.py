ALLOW_TYPE = ["flac", "mp3", "ape", "wav", "aiff", "wv", "tta", "m4a", "ogg", "mpc",
              "opus", "wma", "dsf", "dff", "wmv"]
