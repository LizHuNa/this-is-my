default_app_config = "applications.task.apps.ProjectConfig"
