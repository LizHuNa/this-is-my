from django.apps import AppConfig


class SubsonicConfig(AppConfig):
    name = 'subsonic'
