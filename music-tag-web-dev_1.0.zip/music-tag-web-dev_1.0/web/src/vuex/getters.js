const getters = {
    getUserRole: state => state.common.userRole,
    geFullPath: state => state.common.fullPath,
    getHasMsg: state => state.common.hasMsg
}
export default getters
