import Vue from 'vue'
//按需引入iview
import {
    Tag,
    Drawer,
    Poptip
} from 'view-design';

Vue.component('Tag', Tag);
Vue.component('Drawer', Drawer);
Vue.component('Poptip', Poptip);
