// 统一引入api模块
import Task from './apiUrl/task/task'

export default {
    Task
}
