__version__ = "5.8.0"
__author__ = "UlionTse"


from .server import translate_text, translate_html, translators_pool, get_languages, preaccelerate_and_speedtest
